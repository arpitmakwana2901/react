import React from 'react'
import StudentList from '../components/Studentlist'
import StudentForm from '../components/StudentForm'
import StudentDetails from '../components/StudentDetails'
import Navbar from '../components/Navbar'

const Home = () => {
  return (
    <>
    
    <Navbar/>
    </>
  )
}

export default Home