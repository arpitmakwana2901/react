import React from 'react'
import Movie from './components/Movie'

const App = () => {
  return (
    <>
    <Movie/>
    </>
  )
}

export default App