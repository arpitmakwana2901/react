import React from 'react'
import Form from '../component/Form'

const Home = () => {
  return (
    <div>
        <Form/>
    </div>
  )
}

export default Home